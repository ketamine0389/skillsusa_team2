//$.each(flavors["standard"], function(key, value) {
$('body').append('<div>' + value["Name"] + '<div>');
//});